#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>

int
main(int ac, char **av)
{
  char buf[1024];

  while (gets(buf)) {
    char *bp = buf;
    for (;;) {
      char *word = strtok(bp, " \t,().;:_-\"'`\\/");
      if (!word)
        break;

      bp = NULL;
      printf("%s\n", word);
    }
  }

  return 0;
}
