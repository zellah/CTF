void netserv(void);

int
main(int ac, char** av)
{
  netserv();
}
