<?php
$user="ctfuser";
$pass="password";
$host = "127.0.0.1";
$db = "ctfuser";
$db_user="ctfuser";
$db_pass="password";
$db_host = "127.0.0.1";
?>
