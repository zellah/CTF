/** Automatically generated file. DO NOT MODIFY */
package ctf.competition.ctfbank;

public final class BuildConfig {
    public final static boolean DEBUG = false;
}