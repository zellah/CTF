package ctf.competition.ctfbank;
 
import java.util.HashMap;

import org.json.JSONException;
import org.json.JSONObject;
 
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
 
public class MainActivity extends Activity {
     
	private static final String TAG = "MainActivity";
	private static String KEY_SUCCESS = "success";
    private static String KEY_ERROR = "error";
    private static String KEY_ERROR_MSG = "error_msg";
    private static String KEY_UID = "uid";
    private static String KEY_NAME = "name";
    private static String KEY_EMAIL = "email";
    private static String KEY_COOKIE = "cookie";
    public static String KEY_ACCOUNT_TOTAL = "accountTotal";
    private static String KEY_CREATED_AT = "created_at";
	
    AlertDialogManager alert = new AlertDialogManager();
     
    SessionManager session;
     
    Button btnDeposit;
    Button btnChange;
    Button btnLogout;
    
    EditText txtAcct;
    EditText txtDeposit;
    EditText nameField, emailField, acctField, totalField;
    
 
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
         
        session = new SessionManager(getApplicationContext());
        
        Bundle extras = this.getIntent().getExtras();
    	
		if (extras != null) {
			JSONFunctions.loginURL = extras.getString("SERVER_URL");
			JSONFunctions.depositURL = extras.getString("SERVER_URL");
			JSONFunctions.registerURL = extras.getString("SERVER_URL");
			JSONFunctions.changePassURL = extras.getString("SERVER_URL");
		}
         
        nameField = (EditText) findViewById(R.id.nameField);
        emailField = (EditText) findViewById(R.id.emailField);
        acctField = (EditText) findViewById(R.id.acctName);
        totalField = (EditText) findViewById(R.id.acctTotal);
        btnLogout = (Button) findViewById(R.id.btnLogout);
        btnDeposit = (Button) findViewById(R.id.btnDeposit);
        btnChange = (Button) findViewById(R.id.btnChangeInfo);
        
        txtAcct = (EditText) findViewById(R.id.depositAcct);
        txtDeposit = (EditText) findViewById(R.id.depositField);
         
        Toast.makeText(getApplicationContext(), "User Login Status: " + session.isLoggedIn(), Toast.LENGTH_LONG).show();
         
         
        session.checkLogin();
         
        HashMap<String, String> user = session.getUserDetails();
         
        String name = user.get(SessionManager.KEY_NAME);
         
        String email = null;
        email = user.get(SessionManager.KEY_EMAIL);
        
        String accountName = user.get(SessionManager.KEY_ACCOUNT);
        
        float savings = Float.parseFloat(user.get(SessionManager.KEY_ACCOUNT_TOTAL));
         
        nameField.setText(name);
        emailField.setText(email);
        acctField.setText(accountName);
        totalField.setText(Float.toString(savings));
         
        btnLogout.setOnClickListener(new View.OnClickListener() {
             
            @Override
            public void onClick(View arg0) {
                session.logoutUser();
            }
        });
        
        btnChange.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Intent i = new Intent(MainActivity.this, UpdateActivity.class);
				startActivity(i);
			}
		});
        
        btnDeposit.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				String acct = txtAcct.getText().toString();
				String savings = txtDeposit.getText().toString();
				
				JSONFunctions funcs = new JSONFunctions(getApplicationContext());
				JSONObject json = funcs.transferFunds(acct, savings);
            	try {
            		if (json.getString(KEY_SUCCESS) != null) {
            			String res = json.getString(KEY_SUCCESS);
            			if (Integer.parseInt(res) == 2) {
            				JSONObject json_user = json.getJSONObject("user");
            				Toast.makeText(getApplicationContext(), "TRANSFER SUCCESS!", Toast.LENGTH_SHORT).show();
            				totalField.setText("" + json_user.get(KEY_ACCOUNT_TOTAL));         				
            				session.setSavings(Float.parseFloat(json_user.getString(KEY_ACCOUNT_TOTAL)));
            			}
            			else if (Boolean.parseBoolean(json.getString(KEY_ERROR))) {
            				Toast.makeText(getApplicationContext(), json.getString(KEY_ERROR_MSG), Toast.LENGTH_SHORT).show();
            			}
            		}
            	}
            	catch (JSONException e) {
            		e.printStackTrace();
            		Log.d(TAG, e.toString());
            	}
			}
		});
    }
    @Override
	protected void onResume() {
		super.onResume();
		
		session.checkLogin();
		
        HashMap<String, String> user = session.getUserDetails();
         
        String name = user.get(SessionManager.KEY_NAME);
         
        String email = null;
        email = user.get(SessionManager.KEY_EMAIL);
        
        String accountName = user.get(SessionManager.KEY_ACCOUNT);
        
        float savings = Float.parseFloat(user.get(SessionManager.KEY_ACCOUNT_TOTAL));
         
        nameField.setText(name);
        emailField.setText(email);
        acctField.setText(accountName);
        totalField.setText(Float.toString(savings));
	}
         
}
