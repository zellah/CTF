package ctf.competition.ctfbank;
 
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
 
import android.util.Log;

public class LoginActivity extends Activity {
     
	private static final String TAG = "LoginActivity";
	
	private static String KEY_SUCCESS = "success";
    private static String KEY_ERROR = "error";
    private static String KEY_ERROR_MSG = "error_msg";
    private static String KEY_UID = "uid";
    private static String KEY_NAME = "name";
    private static String KEY_EMAIL = "email";
    private static String KEY_SID = "sid";
    private static String KEY_COOKIE = "cookie";
    private static String KEY_ACCOUNT = "account";
    public static String KEY_ACCOUNT_TOTAL = "accountTotal";
    private static String KEY_CREATED_AT = "created_at";
	
    EditText txtUsername, txtPassword, txtEmail;
     
    Button btnLogin, btnRegister;
     
    AlertDialogManager alert = new AlertDialogManager();
     
    SessionManager session;
 
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
         
        session = new SessionManager(getApplicationContext());  
        
        Bundle extras = this.getIntent().getExtras();
    	
		if (extras != null) {
			JSONFunctions.loginURL = extras.getString("SERVER_URL");
			JSONFunctions.depositURL = extras.getString("SERVER_URL");
			JSONFunctions.registerURL = extras.getString("SERVER_URL");
			JSONFunctions.changePassURL = extras.getString("SERVER_URL");
		}
        
        if (session.isLoggedIn()) {
        	
            Intent main = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(main);
             
            finish();
        }
        else 
        {
	        txtUsername = (EditText) findViewById(R.id.loginUsername);
	        txtPassword = (EditText) findViewById(R.id.loginPassword); 
	         
	        Toast.makeText(getApplicationContext(), "User Login Status: " + session.isLoggedIn(), Toast.LENGTH_LONG).show();
	         
	         
	        btnLogin = (Button) findViewById(R.id.btnLogin);
	        
	        btnRegister = (Button) findViewById(R.id.btnLinkToRegisterScreen);
	         
	         
	        btnLogin.setOnClickListener(new View.OnClickListener() {
	             
	            @Override
	            public void onClick(View arg0) {
	                String username = txtUsername.getText().toString();
	                String password = txtPassword.getText().toString();
	                if(username.trim().length() > 0 && password.trim().length() > 0){
	                    
	                	JSONFunctions funcs = new JSONFunctions(getApplicationContext());
	                	JSONObject json = funcs.loginUser(username, password);
	                	try {
	                		if (json.getString(KEY_SUCCESS) != null) {
	                			String res = json.getString(KEY_SUCCESS);
	                			if (Integer.parseInt(res) == 1) {
	                				JSONObject json_user = json.getJSONObject("user");
	                                
	                                
	                				String sav = json_user.getString(KEY_ACCOUNT_TOTAL);
	                				float savings = Float.parseFloat(sav);
	                				session.createLoginSession(json_user.getString(KEY_NAME), json_user.getString(KEY_EMAIL), 
	                						json.getString(KEY_SID), json.getString(KEY_COOKIE), json_user.getString(KEY_ACCOUNT), 
	                						savings);
	                                Log.d(TAG, "cookie = " + json.getString(KEY_COOKIE));
	                                
	                                Intent dashboard = new Intent(getApplicationContext(), MainActivity.class);
	                                startActivity(dashboard);
	                                 
	                                finish();
	                			}
	                			else{
	                				String err = json.getString(KEY_ERROR);
		                			if (Integer.parseInt(err) == 1) {
		                				alert.showAlertDialog(LoginActivity.this, "Login failed..", json.getString(KEY_ERROR_MSG), false);
		                			}
	                			}
	                		}
	                		else {
	                			alert.showAlertDialog(LoginActivity.this, "Login failed..", "SUCCESS NOT RETURNED", false);
	                		}
	                	}
	                	catch (JSONException e) {
	                		e.printStackTrace();
	                		Log.d(TAG, e.toString());
	                	}
	                              
	                }else{
	                    alert.showAlertDialog(LoginActivity.this, "Login failed..", "Please enter username and password", false);
	                }
	                 
	            }
	        });
	        btnRegister.setOnClickListener(new View.OnClickListener() {
	            
	            @Override
	            public void onClick(View arg0) {
	            	Intent i = new Intent(getApplicationContext(),
	                        RegisterActivity.class);
	                startActivity(i);
	                finish();
	            }
	        });
        }
        
    }   
    
    @Override
    public void onBackPressed() {
    	finish();
    }
}
