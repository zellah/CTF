package ctf.competition.ctfbank;

import org.json.JSONException;
import org.json.JSONObject;
 
import ctf.competition.ctfbank.JSONFunctions;
 
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
 
public class RegisterActivity extends Activity {
    Button btnRegister;
    Button btnLinkToLogin;
    EditText inputFullName;
    EditText inputEmail;
    EditText inputPassword;
    EditText inputAcct;
    TextView registerErrorMsg;
    
    SessionManager session;
     
    private static String KEY_SUCCESS = "success";
    private static String KEY_ERROR = "error";
    private static String KEY_ERROR_MSG = "error_msg";
    private static String KEY_UID = "uid";
    private static String KEY_NAME = "name";
    private static String KEY_EMAIL = "email";
    private static String KEY_SID = "sid";
    private static String KEY_COOKIE = "cookie";
    public static final String KEY_ACCOUNT = "account";
    public static final String KEY_ACCOUNT_TOTAL = "accountTotal";
    private static String KEY_CREATED_AT = "created_at";
 
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register);
 
        session = new SessionManager(getApplicationContext());
        
        inputFullName = (EditText) findViewById(R.id.registerName);
        inputEmail = (EditText) findViewById(R.id.registerEmail);
        inputPassword = (EditText) findViewById(R.id.registerPassword);
        inputAcct = (EditText) findViewById(R.id.acctName);
        btnRegister = (Button) findViewById(R.id.btnRegister);
        btnLinkToLogin = (Button) findViewById(R.id.btnLinkToLoginScreen);
         
        btnRegister.setOnClickListener(new View.OnClickListener() {         
            public void onClick(View view) {
                String name = inputFullName.getText().toString();
                String email = inputEmail.getText().toString();
                String password = inputPassword.getText().toString();
                String acct = inputAcct.getText().toString();
                JSONFunctions userFunction = new JSONFunctions(getApplicationContext());
                JSONObject json = userFunction.registerUser(name, email, password, acct);
                 
                try {
                    if (json.getString(KEY_SUCCESS) != null) {
                        String res = json.getString(KEY_SUCCESS); 
                        if(Integer.parseInt(res) == 1){
                            JSONObject json_user = json.getJSONObject("user");
                            String account = json_user.getString(KEY_ACCOUNT);
                            String sav = json_user.getString(KEY_ACCOUNT_TOTAL);
            				float savings = Float.parseFloat(sav);
                            session.createLoginSession(json_user.getString(KEY_NAME), 
                            		json_user.getString(KEY_EMAIL), json.getString(KEY_SID), 
                            		json.getString(KEY_COOKIE), json_user.getString(KEY_ACCOUNT), 
                            		savings);
                            Intent dashboard = new Intent(getApplicationContext(), MainActivity.class);
                            startActivity(dashboard);
                            finish();
                        }else{
                            registerErrorMsg.setText("Error occured in registration");
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });
 
        btnLinkToLogin.setOnClickListener(new View.OnClickListener() {
 
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(),
                        LoginActivity.class);
                startActivity(i);
                finish();
            }
        });
    }
}
