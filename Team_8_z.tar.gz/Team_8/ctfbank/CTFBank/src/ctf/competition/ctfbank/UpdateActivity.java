package ctf.competition.ctfbank;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class UpdateActivity extends Activity {

	private static final String TAG = "MainActivity";
	private static String KEY_SUCCESS = "success";
    private static String KEY_ERROR = "error";
    private static String KEY_ERROR_MSG = "error_msg";
    private static String KEY_UID = "uid";
    private static String KEY_NAME = "name";
    private static String KEY_EMAIL = "email";
    private static String KEY_COOKIE = "cookie";
    public static String KEY_ACCOUNT_TOTAL = "accountTotal";
    private static String KEY_CREATED_AT = "created_at";
	
    AlertDialogManager alert = new AlertDialogManager();
     
    SessionManager session;
    
    EditText updAcctName, updEmail, updPass;
    
    Button btnUpdateInfo;
    
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.change_info);
        
        updAcctName = (EditText) findViewById(R.id.updateAcctName);
        updEmail = (EditText) findViewById(R.id.updateEmail);
        updPass = (EditText) findViewById(R.id.updatePassword);
        
        btnUpdateInfo = (Button) findViewById(R.id.btnUpdateInfo);
        
        session = new SessionManager(getApplicationContext());
        
        session.checkLogin();
        
        btnUpdateInfo.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
				String acctName = updAcctName.getText().toString();
				String email = updEmail.getText().toString();
				String password = updPass.getText().toString();
				
				session.updateAcctInfo(acctName, email);
				
				JSONFunctions funcs = new JSONFunctions(getApplicationContext());
				JSONObject json = funcs.changePass(password);
            	try {
            		if (json.getString(KEY_SUCCESS) != null) {
            			String res = json.getString(KEY_SUCCESS);
            			if (Integer.parseInt(res) == 3) {
            				Toast.makeText(getApplicationContext(), "CHANGE PASSWORD SUCCESS!", Toast.LENGTH_SHORT).show();
            			}
            			else {
            				String err = json.getString(KEY_ERROR_MSG);
            				Toast.makeText(getApplicationContext(), "ERROR: " + err, Toast.LENGTH_SHORT).show();
            			}
            		}
            	}
            	catch (JSONException e) {
            		e.printStackTrace();
            		Log.d(TAG, e.toString());
            	}
            	
				finish();
			}
		});
        
    }
	
}
