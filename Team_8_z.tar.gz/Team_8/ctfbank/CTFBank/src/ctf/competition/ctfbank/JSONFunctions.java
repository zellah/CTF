package ctf.competition.ctfbank;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
 
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONObject;
 
import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;
 
public class JSONFunctions {
     
    private JSONParser jsonParser;
     
    public static String loginURL = "http://18.126.0.129/ctfbank/serverBackend.php";
    public static String registerURL = "http://18.126.0.129/ctfbank/serverBackend.php";
    public static String depositURL = "http://18.126.0.129/ctfbank/serverBackend.php";
    public static String changePassURL = "http://18.126.0.129/ctfbank/serverBackend.php";
     
    private static String login_tag = "login";
    private static String register_tag = "register";
    private static String deposit_tag = "deposit";
    private static String change_pass_tag = "changePass";
     
    public JSONFunctions(Context context){
        jsonParser = new JSONParser(context);
    }
     
    public JSONObject loginUser(String username, String password){
        List<NameValuePair> params = new ArrayList<NameValuePair>();
        params.add(new BasicNameValuePair("tag", login_tag));
        params.add(new BasicNameValuePair("username", username));
        params.add(new BasicNameValuePair("password", password));
        params.add(new BasicNameValuePair("url", loginURL));
        JSONObject json = null;
		try {
			json = new executeHTTP().execute(params).get();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        return json;
    }
    
    public JSONObject transferFunds(String acct, String savings) {
    	List<NameValuePair> params = new ArrayList<NameValuePair>();
        params.add(new BasicNameValuePair("tag", deposit_tag));
        params.add(new BasicNameValuePair("account", acct));
        params.add(new BasicNameValuePair("transfer", savings));
        params.add(new BasicNameValuePair("url", depositURL));
        JSONObject json = null;
		try {
			json = new executeHTTP().execute(params).get();
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (ExecutionException e) {
			e.printStackTrace();
		}
        return json;
    }
    
    public JSONObject changePass(String pass) {
    	List<NameValuePair> params = new ArrayList<NameValuePair>();
        params.add(new BasicNameValuePair("tag", change_pass_tag));
        params.add(new BasicNameValuePair("pwd", pass));
        params.add(new BasicNameValuePair("url", changePassURL));
        JSONObject json = null;
		try {
			json = new executeHTTP().execute(params).get();
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (ExecutionException e) {
			e.printStackTrace();
		}
        return json;
    }
     
    public JSONObject registerUser(String name, String email, 
    		String password, String acct){
        List<NameValuePair> params = new ArrayList<NameValuePair>();
        params.add(new BasicNameValuePair("tag", register_tag));
        params.add(new BasicNameValuePair("username", name));
        params.add(new BasicNameValuePair("email", email));
        params.add(new BasicNameValuePair("password", password));
        params.add(new BasicNameValuePair("account", acct));
        params.add(new BasicNameValuePair("url", registerURL));
        JSONObject json = null;
		try {
			json = new executeHTTP().execute(params).get();
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (ExecutionException e) {
			e.printStackTrace();
		}
        return json;
    }
    
     
    @SuppressWarnings("unchecked")
    private class executeHTTP extends AsyncTask <List<NameValuePair>, JSONObject, JSONObject>{

            protected JSONObject doInBackground(List<NameValuePair>...arg) {
            	List<NameValuePair> list = new ArrayList<NameValuePair>();
            	list = arg[0];
            	String log_reg = "";
            	for (int i = 0; i<list.size(); i++) {
            		NameValuePair nvp = list.get(i);
            		if (nvp.getName().equals("url")) {
            			log_reg = nvp.getValue();
            		}
            	}
            	return jsonParser.getJSONFromUrl(log_reg, list);
            }

            protected JSONObject onPostExecute(JSONObject...objects) {
            		return objects[0];
            }

    }
}

