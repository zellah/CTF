
package ctf.competition.ctfbank;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import android.util.Base64;
import android.util.Log;

public class ServerInterface {

	private final static String TAG = "CTFBank";
	public static String hash_key = "";
	public static final String SERVER_URL = "http://18.126.0.129/ctfbank/serverBackend.php";

	@SuppressWarnings("deprecation")
	public static String sendMsg(String msg) {
		String hash = encryptMsg(msg);
		String data = "command=" + URLEncoder.encode("postMsg");
		data += "&msg=" + URLEncoder.encode(msg);
		data += "&hash=" + URLEncoder.encode(hash);
		return executeHttpRequest(data);
	}
	
	@SuppressWarnings("deprecation")
	public static String receiveMsgs() {
		String data = "command=" + URLEncoder.encode("receiveMsgs");
		return executeHttpRequest(data);
	}
	
	@SuppressWarnings("deprecation")
	public static String getSecret() {
		String data = "command=" + URLEncoder.encode("getSecret");
		return executeHttpRequest(data);
	}

	private static String encryptMsg(String msg) {
		String retVal = "";
		try {
			Mac mac = Mac.getInstance("HmacSHA256");
			SecretKeySpec secret = new SecretKeySpec(
					hash_key.getBytes("UTF-8"), mac.getAlgorithm());
			mac.init(secret);
			byte[] digest = mac.doFinal(msg.getBytes());
			Log.d(TAG, "BYTES IN HEX: " + bytesToHex(digest));
			retVal = bytesToHex(digest);
		} catch (Exception e) {
			Log.d(TAG, e.toString());
		}

		return retVal;
	}
	public static String bytesToHex(byte[] bytes) {
		final char[] hexArray = {'0','1','2','3','4','5','6','7','8','9','a','b','c','d','e','f'};
	    char[] hexChars = new char[bytes.length * 2];
	    int v;
	    for ( int j = 0; j < bytes.length; j++ ) {
	        v = bytes[j] & 0xFF;
	        hexChars[j * 2] = hexArray[v >>> 4];
	        hexChars[j * 2 + 1] = hexArray[v & 0x0F];
	    }
	    return new String(hexChars);
	}

	private static String executeHttpRequest(String data) {
		String result = "";
		try {
			URL url = new URL(SERVER_URL);
			URLConnection connection = url.openConnection();

			connection.setDoInput(true);
			connection.setDoOutput(true);
			connection.setUseCaches(false);
			connection.setRequestProperty("Content-Type",
					"application/x-www-form-urlencoded");

			DataOutputStream dataOut = new DataOutputStream(
					connection.getOutputStream());
			dataOut.writeBytes(data);
			dataOut.flush();
			dataOut.close();

			DataInputStream dataIn = new DataInputStream(
					connection.getInputStream());
			String inputLine;
			while ((inputLine = dataIn.readLine()) != null) {
				result += inputLine;
			}
			dataIn.close();
		} catch (IOException e) {
			e.printStackTrace();
			result = null;
		}

		return result;
	}
}
