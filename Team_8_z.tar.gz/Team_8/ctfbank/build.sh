#!/bin/bash
cd CTFBank

ant clean
ant release

#sign APK with key
mv bin/team8CTFBank-release-unsigned.apk bin/team8CTFBank-signed.apk
jarsigner -verbose -sigalg SHA1withRSA -digestalg SHA1 -keystore 8-keystore.keystore bin/team8CTFBank-signed.apk team8

#align
zipalign -v 4 bin/team8CTFBank-signed.apk bin/team8CTFBank.apk
#copy apk to main player package
cp bin/team8CTFBank.apk ../ctfbank_8.apk
