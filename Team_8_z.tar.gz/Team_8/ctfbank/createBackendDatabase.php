<?php
    require "globals.php";
    
    $connection = pg_connect("host=$host dbname=$db user=$user password=$pass")
    or die ("Could not connect to server\n");
    
    $query = "DROP TABLE IF EXISTS bank_users";
    pg_query($connection, $query) or die("Cannot execute query: $query\n");
    
    $query = "CREATE TABLE bank_users(uid SERIAL, username text, password text, email text, account text, savings float)";
    pg_query($connection, $query) or die("Cannot execute query: $query\n");
    
    pg_close($connection);
    
    ?>
