#!/bin/bash
/etc/init.d/apache2 stop
