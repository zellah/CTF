<?php
    require "globals.php";
    
    //session_id();
    //session_name();
    //session_start();
    
    $register="register";
    $login="login";
    $deposit="deposit";
    $changePwd="changePass";
    
    
    $connection = pg_connect("host=$db_host dbname=$db user=$db_user password=$db_pass")
    or die ("Could not connect to server\n");
    
    if(isset($_REQUEST['tag'])) {
        if($_REQUEST['tag'] == $deposit) {
            session_start();
            //code for logged in
            $user = $_SESSION["user"];
            $pass = $_SESSION["pass"];
            
            $deposit_acct = $_REQUEST["account"];
            $transfer_amount = $_REQUEST["transfer"];
            
            //GET PREVIOUS BALANCE AND UPDATE
            $query = "SELECT savings FROM bank_users WHERE username='$user' AND password='$pass'";
            $rs = pg_query($connection, $query) or die("Cannot execute query: $query\n");
            $row=pg_fetch_row($rs);
            $savings = $row[0];
            $new_savings = NULL;
            $new_savings = $savings - $transfer_amount;
            $new_savings = (float)$new_savings;
            $new_acct_total = $new_savings;
            $query = "UPDATE bank_users SET savings=$new_savings WHERE username='$user' AND password='$pass'";
            pg_query($connection, $query) or die("Cannot execute query: $query\n");
            
            //GET PREVIOUS BALANCE OF TRANSFER ACCT AND UPDATE
            $query = "SELECT savings FROM bank_users WHERE account='$deposit_acct'";
            $rs = pg_query($connection, $query) or die("Cannot execute query: $query\n");
            $row=pg_fetch_row($rs);
            $savings = $row[0];
            $new_savings = NULL;
            $new_savings = $savings + $transfer_amount;
            $new_savings = (float)$new_savings;
            $query = "UPDATE bank_users SET savings=$new_savings WHERE account='$deposit_acct'";
            pg_query($connection, $query) or die("Cannot execute query: $query\n");
            
            //SEND RESPONSE IF SUCCESS
            $response["success"]=2;
            $response["name"]=$user;
            $response["password"]=$pass;
            //$response["uid"]=$row[0];
            $response["sid"] = session_name();
            $response["cookie"] = session_id();
            $response["DEBUG"] = $sid;
            $response["user"]["name"] = $user;
            $response["user"]["accountTotal"] = $new_acct_total;
            echo json_encode($response);
        }
        elseif($_REQUEST['tag'] == $changePwd) {
            session_start();
            //code for logged in
            $user = $_SESSION["user"];
            $pass = $_SESSION["pass"];
            
            $new_pass = $_REQUEST["pwd"];
            
            //UPDATE FIELD
            $query = "UPDATE bank_users SET password=$new_pass WHERE username='$user'";
            pg_query($connection, $query) or die("Cannot execute query: $query\n");
            $response["success"]=3;
            echo json_encode($response);
        }
        elseif($_REQUEST['tag'] == $register) {
            //guest code / registering users
            if(isset($_REQUEST['username']) && isset($_REQUEST['password']) && isset($_REQUEST['email']))
            {
                $user = trim($_REQUEST['username']);
                $pass = trim($_REQUEST['password']);
                $email = trim($_REQUEST['email']);
                $acc = trim($_REQUEST['account']);
                $savings = "200.0";
                $query = "INSERT INTO bank_users VALUES(DEFAULT,'$user','$pass','$email','$acc','$savings')";
                pg_query($connection, $query) or die("Cannot execute query: $query\n");
                
                //$user = trim($_REQUEST['username']);
                //$pass = trim($_REQUEST['password']);
                $query = "SELECT * FROM bank_users WHERE username='$user' AND password='$pass'";
                $rs = pg_query($connection, $query) or die("Cannot execute query: $query\n");
                $row=pg_fetch_row($rs);
                //echo $row[0];
                if(isset($row[0]))
                {
                    //session_destroy();
                    //log in user!
                    //$sid = $user.$pass;
                    session_name("PHPSESSID");
                    session_id(md5($pass));
                    //setcookie(session_name(), session_id());
                    //setcookie($user, $pass, time()+3600);
                    //session_regenerate_id(true);
                    session_start();
                    
                    $_SESSION["user"]=$user;
                    $_SESSION["pass"]=$pass;
                    $response["success"] = 1;
                    $response["uid"] = $row[0];
                    $response["sid"] = session_name();
                    $response["cookie"] = session_id();
                    $response["user"]["name"] = $_SESSION["user"];
                    $response["user"]["email"] = $row[3];
                    
                    //$query = "SELECT savings FROM bank_users WHERE username='$user' AND password='$pass'";
                    //$rs = pg_query($connection, $query) or die("Cannot execute query: $query\n");
                    //$row=pg_fetch_row($rs);
                    
                    $response["user"]["account"] = $row[4];
                    $response["user"]["accountTotal"] = $row[5];
                    $response["user"]["created_at"] = time();
                    $response["user"]["updated_at"] = time();
                    echo json_encode($response);
                    //setcookie(session_name(), session_id(), time()+3600);
                }
                
            }
            else
            {
                //no current user
                //no credentials sent
                $response["error"] = 1;
                $response["error_msg"] = "CREDENTIALS MISSING";
                echo json_encode($response);
            }
        }
        elseif($_REQUEST['tag'] == $login) {
            if(isset($_REQUEST['username']) && isset($_REQUEST['password']))
            {
                $user = trim($_REQUEST['username']);
                $pass = trim($_REQUEST['password']);
                $query = "SELECT * FROM bank_users WHERE username='$user' AND password='$pass'";
                //$rs = pg_query($connection, $query) or die("Cannot execute query: $query\n");
                $rs = pg_query($connection, $query);
                $row=pg_fetch_row($rs);
                //echo $row[0];
                if(isset($row[0]))
                {
                    session_name("PHPSESSID");
                    session_id(md5($pass));
                    //setcookie(session_name(), session_id());
                    session_start();
                    //log in user!
                    $_SESSION["user"]=$user;
                    $_SESSION["pass"]=$pass;
                    $response["success"] = 1;
                    $response["uid"] = $row[0];
                    $response["sid"] = session_name();
                    $response["cookie"] = session_id();
                    $response["user"]["name"] = $_SESSION["user"];
                    $response["user"]["email"] = $row[3];
                    
                    /*
                     $query = "SELECT account FROM bank_users WHERE username='$user' AND password='$pass'";
                     $rs = pg_query($connection, $query) or die("Cannot execute query: $query\n");
                     $row=pg_fetch_row($rs);
                     */
                    
                    $response["user"]["account"] = $row[4];
                    
                    /*
                     $query = "SELECT savings FROM bank_users WHERE username='$user' AND password='$pass'";
                     $rs = pg_query($connection, $query) or die("Cannot execute query: $query\n");
                     $row=pg_fetch_row($rs);
                     */
                    
                    $response["user"]["accountTotal"] = $row[5];
                    $response["user"]["created_at"] = time();
                    $response["user"]["updated_at"] = time();
                    echo json_encode($response);
                }
                else {
                    //didn't find user
                    //
                    session_name("error");
                    session_id("error");
                    //setcookie(session_name(), session_id());
                    session_start();
                    $response["success"] = 0;
                    $response["error"] = 1;
                    $response["error_msg"] = "Incorrect email or password!";
                    echo json_encode($response);
                }
            }
        }
        else {
            //TAG NOT SET
            $response["error"] = 2;
            $response["error_msg"] = "TAG NOT SET";
            echo json_encode($response);
        }
        
    }
    
    
    ?>
