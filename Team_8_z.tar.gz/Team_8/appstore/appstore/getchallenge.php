<?php
# MIT/LL CTF 2013 App Store
# Copyright (c) 2013 Massachusetts Institute of Technology

require "dbutil.php"
?>

<link rel="stylesheet" type="text/css" href="style.css" media="screen" />

<?php
	echo "Downloading ... ";
	echo $_GET['file'] . "</br>";
	$rc = new mysqli($HOST, $USER, $PASS, $MY_DB);
	$query = "select apk from apks where challenge_name = '" . $_GET['file'] . "' and team_id = (select id from teams where name='" . $_GET['name'] . "')";
	if(!($rc->multi_query($query))) {  
	  die("Database Failed: '" . $rc->error . "'\n");
	}
	$result = $rc->store_result();
	$row = $result->fetch_row();
	$file = $row[0];
	ob_end_clean();
	ob_start();
	header('Content-Disposition: attachment; filename='.$_GET['file'].'.apk'.';');
	header('Content-Type: application/octet-stream');
	header('Content-Length: ' . strval(strlen($file))); 
	header('Content-Transfer-Encoding: binary\n');
	print ($file);
	ob_end_flush();
?>
