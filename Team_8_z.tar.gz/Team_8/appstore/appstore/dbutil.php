<?php
# MIT/LL CTF 2013 App Store
# Copyright (c) 2013 Massachusetts Institute of Technology

require "globals.php";
$link = 0;

function connect_db( $db ) {
  global $HOST, $USER, $PASS, $FAILURE, $SUCCESS, $link;

  $link = mysql_connect( $HOST, $USER, $PASS );
  if ( !$link ) {
    echo "Error, could not connect to database";
	echo mysql_error();
    return $FAILURE;
  }

  $rc = mysql_select_db( $db );
  if ( ! $rc ) {
    echo "Error, could not open database.";
    return $FAILURE;
  }

  return $SUCCESS;
}

function close_db() {
  global $link;
  mysql_close( $link );
}

?>
