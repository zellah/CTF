<?php
# MIT/LL CTF 2013 App Store
# Copyright (c) 2013 Massachusetts Institute of Technology

require "dbutil.php"
?>

<link rel="stylesheet" type="text/css" href="style.css" media="screen" />

<?php
$passwordhash = md5($_POST['admin_password']);
$rc = new mysqli($HOST, $USER, $PASS, $MY_DB);

$query = "select * from teams where name='" . 'admin' . "'";
if($rc->multi_query($query)) {  
  $result = $rc->store_result();
  $row = $result->fetch_row();
  if(strcasecmp($passwordhash, $row[2]) != 0) {
	$result->free();
	die("Invalid Login");
  }
  else {
	$result->free();
	echo "Let's Disk Destroy some 'malicious' apks ...<br/>";
  }  
}
else {
  die("Database Failed: '" . $rc->error . "'\n");
}


$query = 'update apks set apk = "" where challenge_name =\''.$_POST['challengename']. '\' and team_id = (select id from teams where name=\'' . $_POST['name'] . '\')';
if(!$rc->query($query)) {
  die("Challenge removal failed: '" . $rc->error . "'\n");
}
$cmd = 'rm ' . getcwd() . DIRECTORY_SEPARATOR . $_POST['name'] . DIRECTORY_SEPARATOR . $_POST['challengename'].'.apk';
echo '<br>'.$cmd.'</br>';
$execout = '';
$challenge_hash = exec($cmd,$execout);
?>
