<?php
# MIT/LL CTF 2013 App Store
# Copyright (c) 2013 Massachusetts Institute of Technology

require "dbutil.php"
?>

<link rel="stylesheet" type="text/css" href="style.css" media="screen" />

<?php
$passwordhash = md5($_POST['admin_password']);
$rc = new mysqli($HOST, $USER, $PASS, $MY_DB);

$query = "select * from teams where name='" . 'admin' . "'";
if($rc->multi_query($query)) {  
  $result = $rc->store_result();
  $row = $result->fetch_row();
  if(strcasecmp($passwordhash, $row[2]) != 0) {
	$result->free();
	die("Invalid Login");
  }
  else {
	$result->free();
  }  
}
else {
  die("Database Failed: '" . $rc->error . "'\n");
}


$query = 'update teams set passhash =' . '\'' . md5($_POST['password']) . '\' ' . 'where name=\'' . $_POST['name'] . '\'';
if(!$rc->query($query)) {
    die("Password change failed: '" . $rc->error . "'\n");
}
echo "Password changed <br/>";
?>
