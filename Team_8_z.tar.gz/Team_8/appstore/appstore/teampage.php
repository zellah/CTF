<?php
# MIT/LL CTF 2013 App Store
# Copyright (c) 2013 Massachusetts Institute of Technology

require "dbutil.php"
?>

<link rel="stylesheet" type="text/css" href="style.css" media="screen" />

<?php
	echo "This team page belongs to ";
	echo $_GET['name'];

	$rc = new mysqli($HOST, $USER, $PASS, $MY_DB);
	$query = "select challenge_name, apk from apks where team_id = (select id from teams where name = '". $_GET['name'] . "')";
	if(!$rc->multi_query($query))   
	  die("Database Failed: '" . $rc->error . "'\n");
        $result = $rc->store_result();
        if ($result) {
	  while ($row = $result->fetch_row()) {
		echo '<div id="challenge_' . $row[0] . '"><ul>';
		echo '<li><a href="getchallenge.php?name=' . $_GET['name'] . '&file='.$row[0].'">';
		echo $row[0].'</a></li>';

		echo '<li><a href="' . $_GET['name'] . '/' . $row[0].'.apk">';
		echo $row[0].' (from disk)</a></li>';

		echo '<li><a href="filechooser.php?name=' . $_GET['name'] . '&file='.$row[0].'">';
		echo 'upload</a></li>';

		$cmd = 'md5sum ' . getcwd() . DIRECTORY_SEPARATOR . $_GET['name'] . DIRECTORY_SEPARATOR . $row[0].'.apk' . ' | awk \'{print $1}\'';
		$execout = '';
		$challenge_hash = exec($cmd,$execout);
		if(strlen($challenge_hash) == 0) {
			$challenge_hash = "File Not Present";
		}
		else {
			$challenge_hash = 'md5 = ' . $challenge_hash;
		}
		foreach($execout as $s) {
			echo '<li>' . $s . ' (file system)</li>';
		}
                if(strlen($row[1]) > 0)
                  echo '<li>' . md5($row[1]) . ' (database)</li>';
		echo '</ul></div>';

		echo '<br/>';
	  }
	  $result->free();
        }
?>
