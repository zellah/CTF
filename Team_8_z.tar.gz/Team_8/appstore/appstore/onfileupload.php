<?php
# MIT/LL CTF 2013 App Store
# Copyright (c) 2013 Massachusetts Institute of Technology

require "dbutil.php"
?>

<link rel="stylesheet" type="text/css" href="style.css" media="screen" />

<?php
$passwordhash = md5($_POST['password']);

$filename = $_FILES["apkfile"]["tmp_name"];
if(strlen($filename) == 0) {
	die('Submission is zero bytes');
}
$handle = fopen($filename, 'rb');
$contents = fread($handle, filesize($filename));
fclose($handle);

$rc = new mysqli($HOST, $USER, $PASS, $MY_DB);

$query = "select * from teams where name='" . $_POST['name'] . "'";
if($rc->multi_query($query)) {  
  $result = $rc->store_result();
  $row = $result->fetch_row();
  if(strcasecmp($passwordhash, $row[2]) != 0) {
	$result->free();
	die("Invalid Login");
  }
  else {
	$result->free();
  }  
}
else {
  die("Database Failed: '" . $rc->error . "'\n");
}


$frags = explode('.', $_POST['file']);
$query = 'update apks set apk=\'' . $rc->real_escape_string($contents) . '\' where challenge_name = \'' . $frags[0] . '\' and team_id = (select id from teams where name=\'' . $_POST['name'] . '\')';
if (!$rc->query($query)) {
  die("Submission Failed: '" . $rc->error . "'\n");
}

if(!file_exists(getcwd() . DIRECTORY_SEPARATOR . $_POST['name'])) {
	mkdir(getcwd() . DIRECTORY_SEPARATOR . $_POST['name']);
}
rename($filename, getcwd() . DIRECTORY_SEPARATOR . $_POST['name'] . DIRECTORY_SEPARATOR . $_POST['file']);
echo "Submission Succeeded</br>";
echo $_POST['file'] . ": " . $_FILES['apkfile']["name"] . " (md5sum = ". md5($contents) . ")</br>";

?>
