<?php
# MIT/LL CTF 2013 App Store
# Copyright (c) 2013 Massachusetts Institute of Technology
?>
<form action="admin.php" method="post"
enctype="multipart/form-data">
<p>
	Password:
	<input type="password" name="password" />
</p>
<br/>
<input type="submit" name="submit" value="Login" />
</form>
