<?php
# MIT/LL CTF 2013 App Store
# Copyright (c) 2013 Massachusetts Institute of Technology
?>
<html>
<body>

<form action="onfileupload.php" method="post"
enctype="multipart/form-data">


<p>
	New APK file:
	<input type="file" name="apkfile"  />
</p>
<p>
	Password:
	<input type="password" name="password" />
</p>
<br/>

<?php
	echo '<input type="hidden" name="name" value="' . $_GET['name'] . '"/>';
	echo '<input type="hidden" name="file" value="' . $_GET['file'] . '.apk"/>';
?>

<input type="submit" name="submit" value="Submit" />
</form>

</body>
</html>
