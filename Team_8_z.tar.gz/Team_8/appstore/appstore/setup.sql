DROP TABLE IF EXISTS `apks`;
DROP TABLE IF EXISTS `teams`;
DROP TABLE IF EXISTS `cache`;

CREATE TABLE `teams` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `name` text NOT NULL,
      `passhash` text NOT NULL,
      PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

CREATE TABLE `apks` (
    `team_id` int(11) NOT NULL,
    `challenge_name` varchar(80) NOT NULL,
    `apk` longblob NOT NULL,
    PRIMARY KEY (`team_id`, `challenge_name`),
    FOREIGN KEY (`team_id`) references teams(`id`)
) ENGINE=InnoDB CHARSET=latin1;

CREATE TABLE `cache` (
        `time` timestamp NOT NULL,
        `key` char(42) NOT NULL,
        `value` text NOT NULL,
        PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

