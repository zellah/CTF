<?php
# MIT/LL CTF 2013 App Store
# Copyright (c) 2013 Massachusetts Institute of Technology

require "dbutil.php"
?>

<link rel="stylesheet" type="text/css" href="style.css" media="screen" />

<?php
$passwordhash = md5($_POST['password']);
$rc = new mysqli($HOST, $USER, $PASS, $MY_DB);

$query = "select * from teams where name='" . 'admin' . "'";
if($rc->multi_query($query)) {  
  $result = $rc->store_result();
  $row = $result->fetch_row();
  if(strcasecmp($passwordhash, $row[2]) != 0) {
	$result->free();
	echo '<img src="nicetry.gif"/></br>';
	echo '<b><font size="24">NICE TRY</font></b>';
	die("Incorrect Login");
  }
  else {
	$result->free();
	echo "Welcome home admin ...<br/>";
  }  
}
else {
  die("Database Error: '" . $rc->error . "'\n");
}

echo '<div id="menu"><ul>';
echo '<li>Password Reset</li>';
?>
<form action="password_reset.php" method="post"
enctype="multipart/form-data">
<p>
	Team:
	<input type="text" name="name"  />
	New password:
	<input type="password" name="password" />
</p>
<?php
	echo '<input type="hidden" name="admin_password" value="' . $_POST['password'] . '"/>';
?>

<input type="submit" name="submit" value="Change" />
</form>

<?php
echo '<li>Remove Challenge</li>';
?>
<form action="remove_challenge.php" method="post"
enctype="multipart/form-data">
<p>
	Team:
	<input type="text" name="name"  />
	Challenge Name:
	<input type="text" name="challengename" />
</p>
<?php
	echo '<input type="hidden" name="admin_password" value="' . $_POST['password'] . '"/>';
?>

<input type="submit" name="submit" value="Remove" />
</form>
<?php
echo '<li>Execute Command</li>';
?>
<form action="admin.php" method="post"
enctype="multipart/form-data">
<p>
	Command:
	<input type="text" name="cmd"  />
</p>
<?php
	echo '<input type="hidden" name="password" value="' . $_POST['password'] . '"/>';
?>

<input type="submit" name="submit" value="Execute" />
</form>
<?php
  if(isset($_POST['cmd']) &&strlen($_POST['cmd']) > 0) {
		$cmd = $_POST['cmd'];
		echo '<p>command: ';
		echo '<pre>' . $cmd . ' 2>&1' . '</pre>';
		echo '</p>';
		$result = shell_exec($cmd . ' 2>&1');
	        echo '<p>result: ';	
		echo '<pre>' . $result . '</pre>';
		echo '</p>';
  }
?>
<?php
echo '<li>Execute SQL Command</li>';
?>
<form action="admin.php" method="post"
enctype="multipart/form-data">
<p>
	SQL Command:
	<input type="text" name="sql_cmd"  /> 
</p>
<?php
	echo '<input type="hidden" name="password" value="' . $_POST['password'] . '"/>';
?>

<input type="submit" name="submit_sql" value="Execute SQL" />
</form>
<?php
  if(isset($_POST['sql_cmd']) &&strlen($_POST['sql_cmd']) > 0) {
		$sql_cmd = $_POST['sql_cmd'];
		echo '<p>SQL command: ';
		echo '<pre>' . $sql_cmd . '</pre>';
		echo '</p>';
	        echo '<p>SQL result: ';	
                echo '<pre>';
		$rc = new mysqli($HOST, $USER, $PASS, $MY_DB);
		if($rc->multi_query($sql_cmd)) {  
                  do {
                      $result = $rc->store_result();
                      if ($result) {
                          while ($row = $result->fetch_row()) {
                                foreach ($row as $item) {
                                    echo $item . ' ';
                                }
                          }
                          $result->free();
                       }
                    } while ($rc->more_results() && $rc->next_result());
		} else {
		  echo 'Invalid query, error: \'' . $rc->error() . '\'\n';
		}
		echo '</pre></p>';
		
  }
echo '</ul></div>';
?>
