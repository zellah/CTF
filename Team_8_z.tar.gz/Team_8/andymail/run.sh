#!/bin/sh
/root/andymail/andymail
