#!/usr/bin/env sh
/usr/bin/killall -9 andymail

