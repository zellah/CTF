#!/bin/bash
apt-get update
apt-get -y  install postgresql-9.1
apt-get -y  install php5
apt-get -y  install php5-cli
apt-get -y  install php5-pgsql
apt-get -y  install apache2
sudo -u postgres -- createuser ctfuser -s
sudo -u postgres -- createdb --owner ctfuser ctfuser
sudo -u postgres -- psql -c "alter role ctfuser with password 'password';"
#needs to be run from the team server
php createBackendDatabase.php 8
# make server php available to apache
mkdir /var/www/ctfmicro
cp *.php /var/www/ctfmicro
cp *.html /var/www/ctfmicro
# enable IPv4, damn it!
cat > /etc/apache2/ports.conf <<EOF
# If you just change the port or add more ports here, you will likely also
# have to change the VirtualHost statement in
# /etc/apache2/sites-enabled/000-default
# This is also true if you have upgraded from before 2.2.9-3 (i.e. from
# Debian etch). See /usr/share/doc/apache2.2-common/NEWS.Debian.gz and
# README.Debian.gz

NameVirtualHost *:80
Listen 0.0.0.0:80

<IfModule mod_ssl.c>
    # If you add NameVirtualHost *:443 here, you will also have to change
    # the VirtualHost statement in
    # /etc/apache2/sites-available/default-ssl
    # to <VirtualHost *:443>
    # Server Name Indication for SSL named virtual hosts is
    # currently not
    # supported by MSIE on Windows XP.
    Listen 443
</IfModule>

<IfModule mod_gnutls.c>
    Listen 443
</IfModule>
EOF
#sudo echo ServerName localhost >> /etc/apache2/apache2.conf
