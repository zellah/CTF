package ctf.competition.ctfmicro;

import java.util.ArrayList;
import java.util.List;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import org.json.JSONException;
import org.json.JSONObject;

import ctf.competition.ctfmicro.R;

import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.text.InputType;
import android.util.Base64;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class viewMsgsActivity extends Activity {
	
	private final static String TAG = "CTFMicro";
	
	private static String KEY_SUCCESS = "success";
    private static String KEY_ERROR = "error";
    private static String KEY_ERROR_MSG = "error_msg";
    private static String KEY_MSGID = "msg_id";
    private static String KEY_NAME = "name";
    private static String KEY_SID = "sid";
    private static String KEY_COOKIE = "cookie";
    private static String KEY_MESSAGE = "msg";
    private static String KEY_COUNT = "numberMsgs";
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.view_msgs_activity);
		
		EditText tv = (EditText) findViewById(R.id.listMsgsTxt);
		
		JSONFunctions funcs = new JSONFunctions(getApplicationContext());
    	JSONObject json = funcs.receiveMsgs();
    	try {
			if (json.getString(KEY_SUCCESS) != null) {
				int count = json.getInt(KEY_COUNT);
				Log.d(TAG, "COUNT: " + count);
				for (int i = 0; i<count; i++) {
					String id = "message" + i;
					JSONObject json_msg = json.getJSONObject(id);
					String name = json_msg.getString(KEY_NAME);
					String msg = json_msg.getString(KEY_MESSAGE);
					tv.append(name + ": " + msg + "\n");
				}
			}
		} catch (JSONException e) {
			e.printStackTrace();
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	

}
