package ctf.competition.ctfmicro;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
 
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONObject;
 
import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;
 
public class JSONFunctions {
     
    private JSONParser jsonParser;
    
    private final static String TAG = "CTFMicro";
     

    
    public static String loginURL = "http://18.126.0.129/ctfmicro/serverBackend.php";
    public static String registerURL = "http://18.126.0.129/ctfmicro/serverBackend.php";
    public static String sendMsgURL = "http://18.126.0.129/ctfmicro/serverBackend.php";
    public static String receiveMsgsURL = "http://18.126.0.129/ctfmicro/serverBackend.php";
     
    public final static String hash_key = "598461aff14af34e4eb3bab4b37f7543";
    
    private static String login_tag = "login";
    private static String register_tag = "register";
    private static String send_msg_tag = "send_msg";
    private static String receive_msgs_tag = "receive_msgs";
     
    public JSONFunctions(Context context){
        jsonParser = new JSONParser(context);
    }
     
    public JSONObject loginUser(String username, String password){
        List<NameValuePair> params = new ArrayList<NameValuePair>();
        params.add(new BasicNameValuePair("tag", login_tag));
        params.add(new BasicNameValuePair("username", username));
        params.add(new BasicNameValuePair("password", password));
        params.add(new BasicNameValuePair("url", loginURL));
        JSONObject json = null;
		try {
			json = new executeHTTP().execute(params).get();
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (ExecutionException e) {
			e.printStackTrace();
		}
        
        return json;
    }
    
    public JSONObject sendMsg(String user, String msg) {
    	String hash = encryptMsg(msg);
    	
    	List<NameValuePair> params = new ArrayList<NameValuePair>();
        params.add(new BasicNameValuePair("tag", send_msg_tag));
        params.add(new BasicNameValuePair("user", user));
        params.add(new BasicNameValuePair("message", msg));
        params.add(new BasicNameValuePair("hash", hash));
        params.add(new BasicNameValuePair("url", sendMsgURL));
        JSONObject json = null;
		try {
			json = new executeHTTP().execute(params).get();
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (ExecutionException e) {
			e.printStackTrace();
		}
        return json;
    }
    
    public JSONObject receiveMsgs() {
    	List<NameValuePair> params = new ArrayList<NameValuePair>();
        params.add(new BasicNameValuePair("tag", receive_msgs_tag));
        params.add(new BasicNameValuePair("url", receiveMsgsURL));
        JSONObject json = null;
		try {
			json = new executeHTTP().execute(params).get();
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (ExecutionException e) {
			e.printStackTrace();
		}
        return json;
    }
     
    public JSONObject registerUser(String name, String password){
        List<NameValuePair> params = new ArrayList<NameValuePair>();
        params.add(new BasicNameValuePair("tag", register_tag));
        params.add(new BasicNameValuePair("username", name));
        params.add(new BasicNameValuePair("password", password));
        params.add(new BasicNameValuePair("url", registerURL));
        JSONObject json = null;
		try {
			json = new executeHTTP().execute(params).get();
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (ExecutionException e) {
			e.printStackTrace();
		}
		Log.d(TAG, "json_str reg user: " + json.toString());
        return json;
    }
    
    private static String encryptMsg(String msg) {
		String retVal = "";
		try {
			Mac mac = Mac.getInstance("HmacSHA256");
			SecretKeySpec secret = new SecretKeySpec(
					hash_key.getBytes("UTF-8"), mac.getAlgorithm());
			mac.init(secret);
			byte[] digest = mac.doFinal(msg.getBytes());
			Log.d(TAG, "BYTES IN HEX: " + bytesToHex(digest));
			retVal = bytesToHex(digest);
		} catch (Exception e) {
			Log.d(TAG, e.toString());
		}

		return retVal;
	}
	public static String bytesToHex(byte[] bytes) {
		final char[] hexArray = {'0','1','2','3','4','5','6','7','8','9','a','b','c','d','e','f'};
	    char[] hexChars = new char[bytes.length * 2];
	    int v;
	    for ( int j = 0; j < bytes.length; j++ ) {
	        v = bytes[j] & 0xFF;
	        hexChars[j * 2] = hexArray[v >>> 4];
	        hexChars[j * 2 + 1] = hexArray[v & 0x0F];
	    }
	    return new String(hexChars);
	}
     
    @SuppressWarnings("unchecked")
    private class executeHTTP extends AsyncTask <List<NameValuePair>, JSONObject, JSONObject>{

            protected JSONObject doInBackground(List<NameValuePair>...arg) {
            	List<NameValuePair> list = new ArrayList<NameValuePair>();
            	list = arg[0];
            	String log_reg = "";
            	for (int i = 0; i<list.size(); i++) {
            		NameValuePair nvp = list.get(i);
            		if (nvp.getName().equals("url")) {
            			log_reg = nvp.getValue();
            		}
            	}
            	return jsonParser.getJSONFromUrl(log_reg, list);
            }

            protected JSONObject onPostExecute(JSONObject...objects) {
            		return objects[0];
            }

    }
}
