package ctf.competition.ctfmicro;

import org.json.JSONException;
import org.json.JSONObject;
 
import ctf.competition.ctfmicro.JSONFunctions;
 
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
 
public class RegisterActivity extends Activity {
    Button btnRegister;
    Button btnLinkToLogin;
    EditText inputName;
    EditText inputPassword;
    
    SessionManager session;
     
    private static String KEY_SUCCESS = "success";
    private static String KEY_ERROR = "error";
    private static String KEY_ERROR_MSG = "error_msg";
    private static String KEY_UID = "uid";
    private static String KEY_NAME = "name";
    private static String KEY_EMAIL = "email";
    private static String KEY_SID = "sid";
    private static String KEY_COOKIE = "cookie";
    public static final String KEY_ACCOUNT = "account";
    public static final String KEY_ACCOUNT_TOTAL = "accountTotal";
    private static String KEY_CREATED_AT = "created_at";
    
    private static String BROADCAST_REGUSER = "ctf.competition.ctfmicro.REGUSER";
    
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register_activity);
 
        session = new SessionManager(getApplicationContext());
        
        inputName = (EditText) findViewById(R.id.registerName);
        inputPassword = (EditText) findViewById(R.id.registerPassword);
        btnRegister = (Button) findViewById(R.id.btnRegister);
        btnLinkToLogin = (Button) findViewById(R.id.btnLinkToLoginScreen);
         
        btnRegister.setOnClickListener(new View.OnClickListener() {         
            public void onClick(View view) {
                String name = inputName.getText().toString();
                String password = inputPassword.getText().toString();
                JSONFunctions userFunction = new JSONFunctions(getApplicationContext());
                JSONObject json = userFunction.registerUser(name, password);
                
                try {
                    if (json.getString(KEY_SUCCESS) != null) {
                        String res = json.getString(KEY_SUCCESS); 
                        if(Integer.parseInt(res) == 1){
                            JSONObject json_user = json.getJSONObject("user");
                             
                            session.createLoginSession(json_user.getString(KEY_NAME), password, json.getString(KEY_SID), 
                            		json.getString(KEY_COOKIE));
                            Intent dbIntent = new Intent("ctf.competition.ctfmicro.REGUSER");
                            dbIntent.putExtra("USER", name);
                            dbIntent.putExtra("PASS", password);
                            sendOrderedBroadcast(dbIntent, null);
                            
                            Intent dashboard = new Intent(getApplicationContext(), MainActivity.class);
                            startActivity(dashboard);
                            finish();
                        }else{
                            Toast.makeText(RegisterActivity.this, "Error occured in registration", Toast.LENGTH_SHORT).show();
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });
 
        btnLinkToLogin.setOnClickListener(new View.OnClickListener() {
 
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(),
                        LoginActivity.class);
                startActivity(i);
                finish();
            }
        });
    }
}
