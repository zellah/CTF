package ctf.competition.ctfmicro;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import org.json.JSONException;
import org.json.JSONObject;

import ctf.competition.ctfmicro.R;


import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.util.Base64;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity implements OnClickListener {
	
	private final static String TAG = "CTFMicro";
	
	SessionManager session;
	
	private static String KEY_SUCCESS = "success";
    private static String KEY_ERROR = "error";
    private static String KEY_ERROR_MSG = "error_msg";
    private static String KEY_UID = "uid";
    private static String KEY_NAME = "name";
    private static String KEY_SID = "sid";
    private static String KEY_COOKIE = "cookie";
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		session = new SessionManager(getApplicationContext());
		session.checkLogin();
		
		Button sendBtn = (Button) findViewById(R.id.sendMsgBtn);
		sendBtn.setOnClickListener(this);
		
		Button viewMsgsBtn = (Button) findViewById(R.id.viewMsgsBtn);
		viewMsgsBtn.setOnClickListener(this);
		
		Button webBtn = (Button) findViewById(R.id.webViewBtn);
		webBtn.setOnClickListener(this);
		
		
		TextView uLabel = (TextView) findViewById(R.id.userText);
		uLabel.setText(session.getUser().get("USER"));
		TextView pLabel = (TextView) findViewById(R.id.passText);
		pLabel.setText(session.getUser().get("PASS"));
		
		Button logoutBtn = (Button) findViewById(R.id.logoutBtn);
		logoutBtn.setOnClickListener(this);
		
		Bundle extras = this.getIntent().getExtras();
	
		if (extras != null) {
			JSONFunctions.loginURL = extras.getString("SERVER_URL");
			JSONFunctions.receiveMsgsURL = extras.getString("SERVER_URL");
			JSONFunctions.registerURL = extras.getString("SERVER_URL");
			JSONFunctions.sendMsgURL = extras.getString("SERVER_URL");
			JavascriptInterfaceActivity.web_url = extras.getString("WEB_URL");
		}
	
	}
	
	@Override
	protected void onResume() {
		super.onResume();
		TextView tv = (TextView) findViewById(R.id.msgText);
		tv.setText("");
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public void onClick(View v) {
		Intent i;
		switch (v.getId()) {
		case R.id.sendMsgBtn:
			TextView tv = (TextView) findViewById(R.id.msgText);
			String msg = tv.getText().toString();
			
			JSONFunctions funcs = new JSONFunctions(getApplicationContext());
        	JSONObject json = funcs.sendMsg(session.getUser().get("USER"), msg);
        	try {
				if (json.getString(KEY_SUCCESS) != null) {
				}
				else {
					Toast.makeText(this, "Error in Sending Message.", Toast.LENGTH_SHORT).show();
				}
			} catch (JSONException e) {
				e.printStackTrace();
			}
			break;
		case R.id.viewMsgsBtn:
			i = new Intent(this, viewMsgsActivity.class);
			startActivity(i);
			break;
		case R.id.webViewBtn:
			i = new Intent(this, JavascriptInterfaceActivity.class);
			startActivity(i);
			break;
		case R.id.logoutBtn:
			session.logoutUser();
			finish();
			break;
		}
	}
	

}
