package ctf.competition.ctfmicro;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.Service;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;
import android.widget.EditText;

public class MicroPollingService extends Service {
	
	public static String BROADCAST_ACTION = "ctf.competition.ctfmicro.SHOWMSGS";
	public static String MSG_LIST = "msglist";
	public static String TAG = "MicroPollingService";
	
	private static String KEY_SUCCESS = "success";
	private static String KEY_ERROR = "error";
    private static String KEY_ERROR_MSG = "error_msg";
    private static String KEY_MSGID = "msg_id";
    private static String KEY_NAME = "name";
    private static String KEY_SID = "sid";
    private static String KEY_COOKIE = "cookie";
    private static String KEY_MESSAGE = "msg";
    private static String KEY_COUNT = "numberMsgs";
	
	@Override
	  public int onStartCommand(Intent intent, int flags, int startId) {
		
		JSONFunctions funcs = new JSONFunctions(getApplicationContext());
    	JSONObject json = funcs.receiveMsgs();
    	try {
			if (json.getString(KEY_SUCCESS) != null) {
				int count = json.getInt(KEY_COUNT);
				String[] sep_msgs = new String[count];
				Log.d(TAG, "COUNT: " + count);
				for (int i = 0; i<count; i++) {
					String id = "message" + i;
					JSONObject json_msg = json.getJSONObject(id);
					String mid = json_msg.getString(KEY_MSGID);
					String name = json_msg.getString(KEY_NAME);
					String msg = json_msg.getString(KEY_MESSAGE);
					sep_msgs[i] = mid + "=" + name + ": " + msg;
				}
				Intent i = new Intent();
				i.setAction(BROADCAST_ACTION);
				Bundle b = new Bundle();
				b.putCharSequenceArray(MSG_LIST, sep_msgs);
				i.putExtras(b);
				sendBroadcast(i);
			}
		} catch (JSONException e) {
			e.printStackTrace();
		}
    	
	    return Service.START_NOT_STICKY;
	  }
	
	@Override
	public IBinder onBind(Intent arg0) {
		return null;
	}
	
	
}
