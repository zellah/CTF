package ctf.competition.ctfmicro;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

public class IntentReceiver extends BroadcastReceiver {
	
	private static final String TAG = "IntentReceiver";
	
	private static String BROADCAST_REGUSER = "ctf.competition.ctfmicro.REGUSER";
	private static String BROADCAST_GETPASS = "ctf.competition.ctfmicro.GETPASS";

	@Override
	public void onReceive(Context context, Intent intent) {
		if (intent.getAction().equals(BROADCAST_REGUSER)) {
			Log.d(TAG, "REG USER INTENT FOUND");
			
			Bundle extras = intent.getExtras();
			
			if (extras != null) {
				String user = extras.getString("USER");
				String pass = extras.getString("PASS");
				String ret = DatabaseHelper.getInstance(context).insertUser(user, pass);
				setResult(Activity.RESULT_OK, ret, null);
			}
		}
		else if (intent.getAction().equals(BROADCAST_GETPASS)) {
			Log.d(TAG, "GET PASS INTENT FOUND");
			Bundle extras = intent.getExtras();
			
			if (extras != null) {
				String user = extras.getString("USER");
				String password = DatabaseHelper.getInstance(context).getPassword(user);
				setResult(Activity.RESULT_OK, password, null);
			}
		}
	}
}
