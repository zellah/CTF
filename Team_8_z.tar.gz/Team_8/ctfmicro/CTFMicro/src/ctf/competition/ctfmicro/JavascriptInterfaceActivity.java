package ctf.competition.ctfmicro;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.io.InputStream;

import org.json.JSONException;
import org.json.JSONObject;

import ctf.competition.ctfmicro.R;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.widget.Toast;
import android.content.res.AssetManager;

public class JavascriptInterfaceActivity extends Activity {

	public static String TAG = "JavascriptInterfaceAcitivity";

	public static String web_url = "";
	
	private static String KEY_SUCCESS = "success";
	
	WebView wv;
	JavaScriptInterface JSInterface;
	AlarmManager alarm;
	PendingIntent pintent;
	SessionManager session;

	String[] new_msgs;
	Map<Integer, String> old_msgs= new HashMap<Integer, String>();
	
	private BroadcastReceiver receiver = new BroadcastReceiver() {
		@Override
		public void onReceive(Context context, Intent intent) {
			Bundle b = new Bundle();
			b = intent.getExtras();
			new_msgs = b.getStringArray(MicroPollingService.MSG_LIST);
			WebView msgView = (WebView) findViewById(R.id.webview);
			msgView.getSettings().setJavaScriptEnabled(true);
			msgView.setWebChromeClient(new WebChromeClient());
			
			for (int i = 0; i < new_msgs.length; i++) 
			{
				String[] sep_msg = new_msgs[i].split("=");
				
				if (sep_msg != null) {
					if (old_msgs.isEmpty()) {
						msgView.loadUrl("javascript:outputMsgs('" + sep_msg[1] + "')");
						int ii = Integer.parseInt(sep_msg[0]);
						old_msgs.put(ii, sep_msg[1]);
					}
					else {
						if (old_msgs.containsKey(Integer.parseInt(sep_msg[0])))
						{
						}
						else {
							msgView.loadUrl("javascript:outputMsgs('" + sep_msg[1] + "')");
							old_msgs.put(Integer.parseInt(sep_msg[0]), sep_msg[1]);
						}
	
					}
					
				}
				
				
			} 
			
		} 
	};

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.webview_activity);
		
		session = new SessionManager(getApplicationContext());
		session.checkLogin();
		
		wv = (WebView) findViewById(R.id.webview);

		wv.getSettings().setJavaScriptEnabled(true);

		JSInterface = new JavaScriptInterface(this);
		wv.addJavascriptInterface(JSInterface, "interface");
		wv.setWebChromeClient(new WebChromeClient());
		AssetManager am = this.getAssets();
        try {
            InputStream is = am.open("CTFMicro.txt");
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        try {
        	BufferedReader in = new BufferedReader(new InputStreamReader(am.open("CTFMicro.txt")));
        	String line = null;

        	StringBuilder responseData = new StringBuilder();
        	if ((line = in.readLine()) != null) {
        	    responseData.append(line);
        	}
        	Log.d(TAG, "web_url: " + responseData.toString());
        	web_url = responseData.toString();
        	
        } catch (Exception e) {
            Log.e("Buffer Error", "Error converting result " + e.toString());
        }

		wv.loadUrl(web_url);

		Calendar cal = Calendar.getInstance();

		Intent intent = new Intent(this, MicroPollingService.class);
		pintent = PendingIntent.getService(this, 0, intent, 0);
		alarm = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
		alarm.setRepeating(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(),
				10 * 1000, pintent);

	}

	@Override
	protected void onResume() {
		IntentFilter filter = new IntentFilter();
		filter.addAction(MicroPollingService.BROADCAST_ACTION);
		registerReceiver(receiver, filter);
		super.onResume();
	}

	@Override
	protected void onPause() {
		unregisterReceiver(receiver);
		alarm.cancel(pintent);
		super.onPause();
	}

	public class JavaScriptInterface {
		Context mContext;

		JavaScriptInterface(Context c) {
			mContext = c;
		}

		@JavascriptInterface
		public void outputMsgs(String[] msgs) {
			for (int i = 0; i < msgs.length; i++) {
				wv.loadUrl("javascript:(outputMsgs() {" + msgs[i] + "})()");
			}
		}
		
		@JavascriptInterface
		public void sendMsg(String msg) { 
			Log.d(TAG, "YOU DID IT!");
			Toast.makeText(mContext, "YOU DID IT!", Toast.LENGTH_LONG).show();
			JSONFunctions funcs = new JSONFunctions(getApplicationContext());
        	JSONObject json = funcs.sendMsg(session.getUser().get("USER"), msg);
        	try {
				if (json.getString(KEY_SUCCESS) != null) {
				}
				else {
					Toast.makeText(JavascriptInterfaceActivity.this, "Error in Sending Message.", Toast.LENGTH_SHORT).show();
				}
			} catch (JSONException e) {
				e.printStackTrace();
			}
		}

	}

}
