package ctf.competition.ctfmicro;

import java.util.ArrayList;
import java.util.List;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {
	 
	public static String TABLE_NAME = "users";
	public static final String COLUMN_USER = "username";
	public static final String COLUMN_PASS = "password";
	
	private static final String DATABASE_NAME = "microUsers.db";
	private static final int DATABASE_VERSION = 1;
	
    private final Context myContext;
    private static DatabaseHelper mInstance;
    private static SQLiteDatabase myWritableDb;
 
    private static final String[] allColumns = {COLUMN_USER, COLUMN_PASS}; 
    private static final String DATABASE_CREATE = "create table "
        + TABLE_NAME + "(" + COLUMN_USER + " text not null, " + COLUMN_PASS + " text not null);";
    
    private DatabaseHelper(Context context) {
 
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        this.myContext = context;
        
        open();
    }
 
    public static DatabaseHelper getInstance(Context context) {
        if (mInstance == null) {
            mInstance = new DatabaseHelper(context);
        }
        return mInstance;
    }
 
    public SQLiteDatabase getMyWritableDatabase() {
        if ((myWritableDb == null) || (!myWritableDb.isOpen())) {
            myWritableDb = this.getWritableDatabase();
        }
 
        return myWritableDb;
    }
 
    public void open() throws SQLException {
    	myWritableDb = this.getMyWritableDatabase();
      }
    
    @Override
    public void close() {
        super.close();
        if (myWritableDb != null) {
            myWritableDb.close();
            myWritableDb = null;
        }
    }

	@Override
	public void onCreate(SQLiteDatabase db) {
		db.execSQL(DATABASE_CREATE);
	}

	@Override
	public void onUpgrade(SQLiteDatabase arg0, int arg1, int arg2) {
		
	}
	
	public String insertUser(String username, String password) {
		ContentValues values = new ContentValues();
		values.put(COLUMN_USER, username);
		values.put(COLUMN_PASS, password);
		long insertId = myWritableDb.insert(TABLE_NAME, null, values);
		Cursor cursor = myWritableDb.rawQuery("select * from " + TABLE_NAME + ";", null);
		cursor.moveToFirst();
		String retVal = cursor.getString(cursor.getColumnIndex(COLUMN_USER));
		cursor.close();
		if (retVal.equals(username)) {
			return "true";
		}
		else 
		{
			return "false";
		}
	}
	
	public String getPassword(String user) {
		Cursor cursor = myWritableDb.rawQuery("select " + COLUMN_PASS + " from " + TABLE_NAME + " WHERE username='" + user + "';", null);
		cursor.moveToFirst();
		return cursor.getString(0);
	}
}
