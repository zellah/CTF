/** Automatically generated file. DO NOT MODIFY */
package ctf.competition.ctfmicro;

public final class BuildConfig {
    public final static boolean DEBUG = false;
}