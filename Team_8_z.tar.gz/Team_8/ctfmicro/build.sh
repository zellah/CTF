#!/bin/bash
cd CTFMicro

ant clean
ant release

#sign APK with key
mv bin/team8CTFMicro-release-unsigned.apk bin/team8CTFMicro-signed.apk
jarsigner -verbose -sigalg SHA1withRSA -digestalg SHA1 -keystore 8-keystore.keystore bin/team8CTFMicro-signed.apk team8

#align
zipalign -v 4 bin/team8CTFMicro-signed.apk bin/team8CTFMicro.apk
#copy apk to main player package
cp bin/team8CTFMicro.apk ../ctfmicro_8.apk
