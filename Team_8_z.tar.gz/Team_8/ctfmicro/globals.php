<?php
$db_user="ctfuser";
$db_pass="password";
$db_host = "127.0.0.1";
$db = "ctfuser";
?>
