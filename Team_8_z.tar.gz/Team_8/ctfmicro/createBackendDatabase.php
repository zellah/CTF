<?php
    require "globals.php";
    
    $connection = pg_connect("host=$db_host dbname=$db user=$db_user password=$db_pass")
    or die ("Could not connect to server\n");
    
    $query = "DROP TABLE IF EXISTS msgs";
    pg_query($connection, $query) or die("Cannot execute query: $query\n");
    
    $query = "DROP TABLE IF EXISTS microUsers";
    pg_query($connection, $query) or die("Cannot execute query: $query\n");
    
    $query = "CREATE TABLE msgs(uid SERIAL, username text, message text)";
    pg_query($connection, $query) or die("Cannot execute query: $query\n");
    
    $query = "CREATE TABLE microUsers(uid SERIAL, username text, password text)";
    pg_query($connection, $query) or die("Cannot execute query: $query\n");
    
    pg_close($connection);
    
    ?>
