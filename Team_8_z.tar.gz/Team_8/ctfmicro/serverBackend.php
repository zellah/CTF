<?php
    require "globals.php";
    $key = "598461aff14af34e4eb3bab4b37f7543";
    
    $register="register";
    $login="login";
    $send="send_msg";
    $receive="receive_msgs";
    
    $connection = pg_connect("host=$db_host dbname=$db user=$db_user password=$db_pass")
    or die ("Could not connect to server\n");
    
    // get the command
    //$command = $_REQUEST['command'];
    
    if(isset($_REQUEST['tag'])) {
        // determine which command will be run
        if($_REQUEST['tag'] == $send) {
            // get the animal parameter and send the right response
            //echo $_REQUEST['msg'];
            
            session_start();
            //code for logged in
            $user = $_SESSION["user"];
            
            $msg = $_REQUEST['message'];
            $rec_hash = $_REQUEST['hash'];
            //echo "Msg Received" . "\n";
            $hash = hash_hmac('sha256', $msg, $key);
            $hash_enc = base64_encode($hash);
            //if ($hash_enc == $rec_hash) {
            if ($hash == $rec_hash) {
                //echo "CORRECT";
                
                //if correct, add to db for query
                $query = "INSERT INTO msgs VALUES(DEFAULT, '$user', '$msg')";
                pg_query($connection, $query) or die("Cannot execute query: $query\n");
                
                //if msg is correct, send it as response
                $response["success"] = 1;
                $response["sid"] = session_name();
                $response["cookie"] = session_id();
                $response["name"] = $_SESSION["user"];
                $response["message"] = $msg;
                echo json_encode($response);
            }
            else {
                echo "INCORRECT MSG";
                //echo $rec_hash . "---!---" . $hash;
            }
            
            //echo urldecode($_REQUEST['mg']);
        }
        else if ($_REQUEST['tag'] == $receive) {
            //$query = "SELECT * FROM cars LIMIT 5";
            session_start();
            $user = $_SESSION["user"];

            $query = "SELECT * FROM msgs";
            $rs = pg_query($connection, $query) or die("Cannot execute query: $query\n");
            
            if (isset($rs)) {
                $i=0;
                $response["success"] = 1;
                $response["sid"] = session_name();
                $response["cookie"] = session_id();
                $response["numberMsgs"] = pg_num_rows($rs);
            
                while ($row=pg_fetch_row($rs)) {
                    $response["message".$i]["msg_id"] = $row[0];
                    $response["message".$i]["name"] = $row[1];
                    $response["message".$i]["msg"] = $row[2];
                    $response["message".$i]["created_at"] = time();
                    $response["message".$i]["updated_at"] = time();
                    //echo $row[1] . ": " . $row[2] . "-";
                    $i++;
                }
             
                echo json_encode($response);
            }
        }
        else if ($_REQUEST['tag'] == $register) {
            //guest code / registering users
            if(isset($_REQUEST['username']) && isset($_REQUEST['password']))
            {
                $user = $_REQUEST['username'];
                $pass = $_REQUEST['password'];

                $query = "INSERT INTO microUsers VALUES(DEFAULT,'$user','$pass')";
                pg_query($connection, $query) or die("Cannot execute query: $query\n");
                
                //$user = trim($_REQUEST['username']);
                //$pass = trim($_REQUEST['password']);
                $query = "SELECT * FROM microUsers WHERE username='$user' AND password='$pass'";
                $rs = pg_query($connection, $query) or die("Cannot execute query: $query\n");
                $row=pg_fetch_row($rs);
                //echo $row[0];
                if(isset($row[0]))
                {
                    
                    session_name("PHPSESSID");
                    session_id($user.$pass);
                    
                    session_start();
                    
                    $_SESSION["user"]=$user;
                    $_SESSION["pass"]=$pass;
                    $response["success"] = 1;
                    $response["uid"] = $row[0];
                    $response["sid"] = session_name();
                    $response["cookie"] = session_id();
                    $response["user"]["name"] = $_SESSION["user"];

                    $response["user"]["created_at"] = time();
                    $response["user"]["updated_at"] = time();
                    echo json_encode($response);
                    //setcookie(session_name(), session_id(), time()+3600);
                }
                
            }
            else
            {
                //no current user
                //no credentials sent
                $response["error"] = 1;
                $response["error_msg"] = "CREDENTIALS MISSING";
                echo json_encode($response);
            }
        }
        else if ($_REQUEST['tag'] == $login) {
            if(isset($_REQUEST['username']) && isset($_REQUEST['password']))
            {
                $user = $_REQUEST['username'];
                $pass = $_REQUEST['password'];
                $query = "SELECT * FROM microUsers WHERE username='$user' AND password='$pass'";
                $rs = pg_query($connection, $query) or die("Cannot execute query: $query\n");
                $row=pg_fetch_row($rs);
                //echo $row[0];
                if(isset($row[0]))
                {
                    session_name("PHPSESSID");
                    session_id($user.$pass);
                    //setcookie(session_name(), session_id());
                    session_start();
                    //log in user!
                    $_SESSION["user"]=$user;
                    $_SESSION["pass"]=$pass;
                    $response["success"] = 1;
                    $response["uid"] = $row[0];
                    $response["sid"] = session_name();
                    $response["cookie"] = session_id();
                    $response["user"]["name"] = $_SESSION["user"];

                    $response["user"]["created_at"] = time();
                    $response["user"]["updated_at"] = time();
                    echo json_encode($response);
                }
                else {
                    //didn't find user
                    //
                    session_name("error");
                    session_id("error");
                    //setcookie(session_name(), session_id());
                    session_start();
                    $response["success"] = 0;
                    $response["error"] = 1;
                    $response["error_msg"] = "Incorrect email or password!";
                    $response["sid"] = session_name();
                    $response["cookie"] = session_id();
                    echo json_encode($response);
                }
            }
        }

    }
    else {
        //TAG NOT SET
        $response["error"] = 2;
        $response["error_msg"] = "TAG NOT SET";
        echo json_encode($response);
    }
    
    pg_close($connection);
    
?>
