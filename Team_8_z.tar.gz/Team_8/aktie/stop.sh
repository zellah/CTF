#!/bin/sh
killall aktie_server
