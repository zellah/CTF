#!/bin/sh
/root/aktie/aktie_server 

